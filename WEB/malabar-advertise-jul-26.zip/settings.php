<?php
require_once('includes/config.php');

//path to view member image----------------------------------
$UPLOAD_PATH="admin/uploads/";
$UPLOAD_ADV="adv/";
$UPLOAD_GAL="uploads/gallery/";
//path to array----------------------------<em></em>------
 
?>
