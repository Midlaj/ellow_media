<?php
require_once('include/dbconnect.php');

//path to view member image----------------------------------
$UPLOAD_PATH="uploads/";
$UPLOAD_ADV="adv/";
$UPLOAD_GAL="uploads/gallery/";
//path to array----------------------------<em></em>------
 
?>
