
<footer>



<div class="maincontainer">

<div class="col-md-4 ftop">

 <img src="images/footerlogo.jpg">

</div>






<div class="col-md-2 ftop">

<div class="flink">

<a href="http://www.malabaradvertising.com">Home</a>
<a href="about.php">About us</a>
<a href="clients.php">Clients</a>
<a href="availablity.php">Availability</a>
<a href="inquiry.php">Inquiry</a>
<a href="contact.php">Contact</a>
</div>

</div>



<div class="col-md-3">
<div class="fadres">
<h3>Malabar Advertising</h3>
<P>First Floor, FCC Building,<br>Near. Federal Bank Tower,
Arayidathupalam, Calicut-673016</P>
<div class="fmail">info@malabaradvertising.com</div>
<div class="clearfix"></div>

<div class="footerphone">9447054124, 9544924268</div>
</div>

</div>









<div class="col-md-3 ftop">
<h3>Stay Connected</h3>






<div id="social"><a class="facebookBtn smGlobalBtn" href="#" ></a>
			<a class="twitterBtn smGlobalBtn" href="#" ></a>
			<a class="googleplusBtn smGlobalBtn" href="#" ></a>

		</div>
	








</div>

</div>

</footer>





<div class="clearfix"></div>


<div class="footerbottom">




<div class="maincontainer">

<div class="col-md-6">Copy Right @ 2017 Malabar Advertising - All Right Reserved</div>

<div class="col-md-6 text-right"><a href="http://www.ellowmedia.com">Webdesign & Development Company &nbsp;</a>: Ellowmedia IT Crew</div>


</div>

</div>




